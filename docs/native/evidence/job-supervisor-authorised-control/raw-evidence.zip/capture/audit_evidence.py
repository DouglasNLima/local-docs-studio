"""Read existing bytes only. Never import the native backend or launch a fixture."""
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys

root = Path(r'C:\Code\MarkdownReader-native-ux-contract')
out = root / 'artifacts/goal77-job-control-d4261e58b55d6755feddf179ea9e922a687e3e9f'
envelope = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def unique(items):
    result = {}
    for key, value in items:
        assert key not in result, key
        result[key] = value
    return result
def read(p):
    return json.loads(p.read_bytes(), object_pairs_hook=unique)

manifest = read(out / 'files.json')
assert set(manifest) == {p.name for p in out.iterdir() if p.is_file()} - {'files.json'}
assert all(sha(out / name) == digest for name, digest in manifest.items())
r = read(out / 'process.json')
ops = [json.loads(line, object_pairs_hook=unique) for line in (out / 'supervisor.jsonl').read_bytes().splitlines()]
assert ops == r['operations'] and sha(out / 'supervisor.jsonl') == r['supervisorJournalSha256']
assert [x['sequence'] for x in ops] == list(range(len(ops)))
plan = read(out / 'plan.json')
assert sha(out / 'plan.json') == sha(root / 'docs/native/qualification/job-supervisor-control.json')
assert read(out / 'stdout.json') == plan['expectedFixtureReport']
assert (out / 'stderr.jsonl').read_bytes() == b''
assert all(sha(Path(p)) == h for p, h in plan['pythonFiles'].items())
assert all(sha(root / p) == h for p, h in plan['executionFiles'].items())
assert sha(out / 'NativeBufferSelfTest.exe') == plan['fixture']['sha256']
git = lambda *args: subprocess.check_output(['git', '-C', str(root), *args]).decode().strip()
assert git('rev-parse', 'HEAD') == 'd4261e58b55d6755feddf179ea9e922a687e3e9f'
assert not git('status', '--porcelain')
assert git('rev-parse', plan['sourceCommit'] + '^{tree}') == plan['sourceTree']
assert all(hashlib.sha256(subprocess.check_output(['git', '-C', str(root), 'show', plan['sourceCommit'] + ':' + p])).hexdigest() == h for p, h in plan['sourceFiles'].items())
body = (envelope / 'authority-body.txt').read_bytes()
assert hashlib.sha256(body).hexdigest() == '5550d95aafd502981f91a439447e689e61827bf31350341d2285c5b3a13e7e59'
for p in (out / 'owner-before.json', out / 'owner-before-launch.json', envelope / 'authority-api-before.json', envelope / 'authority-api-after-observation.json'):
    a = read(p)
    assert a['id'] == 6726673440 and a['user']['id'] == 33501911 and a['user']['login'] == 'DouglasNLima'
    assert a['created_at'] == a['updated_at'] and a['body'].encode() == body

rows = []
for o in r['jobObservations']:
    raw = o['raw']
    for name, cls, size in (('accounting', 1, 48), ('limits', 9, 144), ('pids', 3, 72)):
        q = raw[name]
        assert q['returnValue'] == 1 and q['winError'] is None and q['informationClass'] == cls
        assert q['capacityBytes'] == size and len(bytes.fromhex(q['rawBytes'])) == size
        assert 0 <= q['returnedBytes'] <= size
    faults, total, active, terminated = struct.unpack_from('<4I', bytes.fromhex(raw['accounting']['rawBytes']), 32)
    flags = struct.unpack_from('<I', bytes.fromhex(raw['limits']['rawBytes']), 16)[0]
    limit = struct.unpack_from('<I', bytes.fromhex(raw['limits']['rawBytes']), 40)[0]
    assigned, count = struct.unpack_from('<2I', bytes.fromhex(raw['pids']['rawBytes']))
    assert raw['accounting']['returnedBytes'] == 48 and raw['limits']['returnedBytes'] == 144
    assert assigned == count <= 8 and raw['pids']['returnedBytes'] == 8 + count * 8
    pids = list(struct.unpack_from('<' + 'Q' * count, bytes.fromhex(raw['pids']['rawBytes']), 8))
    assert (total, active, terminated, flags, limit, pids) == tuple(o['decoded'][k] for k in ('totalProcesses','activeProcesses','terminatedProcesses','limitFlags','activeLimit','processIds'))
    row = dict(phase=o['phase'], total=total, active=active, pids=pids, limitFlags=flags, activeLimit=limit, seconds=o['startedSeconds'])
    if 'targetSeconds' in o:
        row['cleanupElapsedSeconds'] = o['startedSeconds'] - r['cleanupStartedSeconds']
        row['targetSeconds'] = o['targetSeconds']
    rows.append(row)
assert [o['phase'] for o in rows] == plan['phases']
sys.path.insert(0, str(root / 'scripts/native/qualification_hosted'))
from job_evidence import verify_supervision
try:
    verify_supervision(r)
except ValueError as e:
    rejection = str(e)
else:
    raise AssertionError('Failed live evidence unexpectedly accepted')

summary = dict(status='PASS_BYTE_AND_REJECTION_AUDIT_ONLY', nativeResult='FAIL', readiness='BLOCKED', newNativeExecutions=0,
 executionCommit=git('rev-parse','HEAD'), executionTree=git('rev-parse','HEAD^{tree}'), cleanWorktreeAtAudit=True,
 fileManifestValid=True, sourceAndInterpreterHashesValid=True, journalCompleteAndBound=True,
 authorityUnedited=True, authorityCommentId=6726673440, authorityBodySha256=hashlib.sha256(body).hexdigest(),
 driverExitCode=read(envelope/'driver-exit.json')['driverExitCode'], fixturePid=r['processId'], fixtureExitCode=r['exitCode'], nativeChecks=21,
 supervisorPid=r['supervisorPid'], operations=len(ops), fixtureCreateCalls=sum(o['name']=='create' and o['phase']=='BEGIN' for o in ops),
 jobCreateCalls=sum(o['name']=='job' and o['phase']=='BEGIN' for o in ops), assignmentAttempts=r['assignmentAttempts'], retries=r['retryCount'],
 rows=rows, nativeErrors=[o for o in ops if 'error' in o], terminationRequests=r['terminationRequests'],
 closeResults=[o for o in ops if o['name'].startswith('close:') and o['phase']=='END'],
 cleanupVerified=r['cleanupVerified'], emptyMembershipObserved=r['emptyMembershipObserved'], jobHandleClosed=r['jobHandleClosed'],
 cleanupDurationSeconds=r['cleanupFinishedSeconds']-r['cleanupStartedSeconds'], observedExitSeconds=r['observedExitSeconds'],
 expectedVerifierRejection=rejection, driverMissingSuccessRecords=[name for name in ('owner-after.json','terminal.json') if not (out/name).exists()],
 supplementaryAuthorityObservation='capture/authority-api-after-observation.json is external read-only evidence, not a missing driver success record',
 originalFailure='RETAINED_UNCHANGED_CAUSE_INCONCLUSIVE', fixtureIdentityAtExit='MISSING_NATIVE_QUERY_FAILED', unexpectedPidIdentity='INCONCLUSIVE',
 processSha256=sha(out/'process.json'), supervisorJournalSha256=sha(out/'supervisor.jsonl'), scriptSha256=sha(Path(__file__)))
with (envelope / 'audit-result.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(summary, f, indent=2)
print(json.dumps({k:summary[k] for k in ('status','nativeResult','readiness','fixturePid','operations','jobCreateCalls','fixtureCreateCalls','assignmentAttempts','cleanupDurationSeconds','processSha256','supervisorJournalSha256')},indent=2))
