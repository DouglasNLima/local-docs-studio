"""Capture one invocation of the reviewed driver; no retry or native calls."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path(r'C:\Code\MarkdownReader-native-ux-contract')
envelope = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'scripts/native/qualification_hosted'))
import local_job_control as local

assert sys.flags.isolated == 1 and sys.flags.no_site == 1
plan = local.read_json(root / local.PLAN)
local.validate_plan(plan)
local.verify_files(plan)
assert str(Path(sys.executable)).casefold() == plan['pythonExecutable'].casefold()
assert sys.version == plan['pythonVersion']
assert local.digest(root / local.PLAN) == '415e0ecb2e10328e3a6850da926ab1c9ef237072352a7a903fb1f46424081be3'
git = lambda *args: subprocess.check_output(['git', '-C', str(root), *args]).decode().strip()
assert git('rev-parse', 'HEAD') == 'd4261e58b55d6755feddf179ea9e922a687e3e9f'
assert git('rev-parse', 'HEAD^{tree}') == '2768237f85171258cded141101a1213d3c9bd1c6'
assert not git('status', '--porcelain')
assert not (root / 'artifacts/goal77-job-control-d4261e58b55d6755feddf179ea9e922a687e3e9f').exists()
authority = local.read_json(envelope / 'authority-api-before.json')
expected = local.owner_proposal(plan, local.digest(root / local.PLAN), git('rev-parse', 'HEAD'), git('rev-parse', 'HEAD^{tree}'), approved=True)
local.verify_authority(authority, expected, dict(AUTHORISATION_COMMENT_ID='6726673440', AUTHORISATION_BODY_SHA256='5550d95aafd502981f91a439447e689e61827bf31350341d2285c5b3a13e7e59'))
command = [sys.executable, '-I', '-S', 'scripts/native/qualification_hosted/local_job_control.py', '--authorisation-comment-id', '6726673440', '--authorisation-body-sha256', '5550d95aafd502981f91a439447e689e61827bf31350341d2285c5b3a13e7e59']
started = time.monotonic()
receipt = dict(command=command, cwd=str(root), captureParentPid=os.getpid(), startedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(), startedMonotonic=started, wrapperSha256=local.digest(__file__), driverInvocations=1, retries=0)
with (envelope / 'driver-launch.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(receipt, f, indent=2)
with (envelope / 'driver.stdout.bin').open('xb') as stdout, (envelope / 'driver.stderr.bin').open('xb') as stderr:
    child = subprocess.Popen(command, cwd=root, stdout=stdout, stderr=stderr)
    receipt['driverPid'] = child.pid
    receipt['driverExitCode'] = child.wait()
receipt['finishedUtc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt['durationSeconds'] = time.monotonic() - started
receipt['stdoutSha256'] = local.digest(envelope / 'driver.stdout.bin')
receipt['stderrSha256'] = local.digest(envelope / 'driver.stderr.bin')
with (envelope / 'driver-exit.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(receipt, f, indent=2)
print(json.dumps(receipt, indent=2))
raise SystemExit(receipt['driverExitCode'])
