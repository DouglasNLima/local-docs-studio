"""Read-only audit of the spent Goal 77 local control; no native imports/calls.

Only this audit directory receives newly derived output. Inputs are never changed.
"""
import datetime
import hashlib
import json
import math
from pathlib import Path
import struct
import subprocess
import sys
import zipfile

ROOT = Path(r'C:\Code\MarkdownReader-native-ux-contract')
REVIEW = Path(__file__).resolve().parent
E = 'd4261e58b55d6755feddf179ea9e922a687e3e9f'
TREE = '2768237f85171258cded141101a1213d3c9bd1c6'
S = '331dc5ab220e5ca7dd145ff21a650d3d2578111f'
RUN = ROOT / ('artifacts/goal77-job-control-' + E)
OUTER = ROOT / 'artifacts/goal77-job-authorised-execution'
PLAN = ROOT / 'docs/native/qualification/job-supervisor-control.json'
PLAN_SHA = '415e0ecb2e10328e3a6850da926ab1c9ef237072352a7a903fb1f46424081be3'
AUTHORITY_SHA = '5550d95aafd502981f91a439447e689e61827bf31350341d2285c5b3a13e7e59'
PHASES = ['CREATED_EMPTY', 'CONFIGURED_EMPTY', 'BEFORE_ASSIGNMENT',
          'AFTER_ASSIGNMENT', 'AFTER_RESUME', 'PROCESS_EXIT',
          'CLEANUP_0', 'CLEANUP_1', 'CLEANUP_2', 'CLEANUP_3']


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key: ' + key)
        result[key] = value
    return result


def decode(data):
    return json.loads(data, object_pairs_hook=unique,
                      parse_constant=lambda value: require(False, 'Non-finite JSON: ' + value))


def read(path):
    return decode(Path(path).read_bytes())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    return sha(Path(path).read_bytes())


def git(*arguments):
    return subprocess.check_output(['git', '-C', str(ROOT), *arguments])


def number(value):
    return type(value) in (float, int) and math.isfinite(value) and value >= 0


def run():
    require(git('rev-parse', 'HEAD').decode().strip() == E, 'Changed HEAD')
    require(git('rev-parse', E + '^{tree}').decode().strip() == TREE, 'Changed tree')
    review_worktree_status = git('status', '--porcelain').decode().splitlines()
    require(all(line[3:].startswith('docs/') for line in review_worktree_status), 'Non-documentation worktree change')
    plan = read(PLAN)
    require(file_sha(PLAN) == PLAN_SHA and (RUN / 'plan.json').read_bytes() == PLAN.read_bytes(), 'Plan drift')
    require(plan['sourceCommit'] == S and len(plan['sourceFiles']) == len(plan['executionFiles']) == 16, 'Wrong closure')
    for path, expected in plan['sourceFiles'].items():
        blob = git('show', E + ':' + path)
        require(blob == git('show', S + ':' + path) and sha(blob) == expected, 'Canonical source drift: ' + path)
        require(file_sha(ROOT / path) == plan['executionFiles'][path], 'Local source drift: ' + path)
    for path, expected in plan['pythonFiles'].items():
        require(file_sha(path) == expected, 'Python file drift: ' + path)
    fixture = RUN / 'NativeBufferSelfTest.exe'
    require(file_sha(fixture) == plan['fixture']['sha256'] and fixture.stat().st_size == 20480, 'Fixture drift')
    archive = ROOT / plan['fixture']['archive']
    require(file_sha(archive) == plan['fixture']['archiveSha256'], 'Fixture archive drift')
    with zipfile.ZipFile(archive) as z:
        require(z.read(plan['fixture']['member']) == fixture.read_bytes(), 'Fixture differs from retained archive member')
    manifest = read(RUN / 'files.json')
    run_files = {path.name: file_sha(path) for path in RUN.iterdir() if path.is_file()}
    require(set(manifest) == set(run_files) - {'files.json'}, 'Run manifest does not cover exact file set')
    require(all(run_files[name] == digest for name, digest in manifest.items()), 'Run file hash mismatch')
    outer_files = {path.name: file_sha(path) for path in OUTER.iterdir() if path.is_file()}

    expected_authority = dict(schemaVersion=1, repository='DouglasNLima/local-docs-studio', issue=77,
        decision='AUTHORISE_ONE_LOCAL_JOB_FIXTURE_CONTROL', approved=True,
        executionCommit=E, executionTree=TREE, sourceCommit=S, sourceTree=plan['sourceTree'],
        planSha256=PLAN_SHA, fixtureSha256=plan['fixture']['sha256'], pythonFiles=plan['pythonFiles'],
        bounds=plan['bounds'], cleanupTargets=plan['cleanupTargets'],
        exclusion='No HIGHCONTRAST collector, hosted workflow, UI/input/display/appearance change, retry, R01/R02, calibration or policy activation')
    authority_paths = [OUTER / 'authority-api-before.json', RUN / 'owner-before.json', RUN / 'owner-before-launch.json',
                       OUTER / 'authority-api-after-observation.json']
    for path in authority_paths:
        authority = read(path)
        require(type(authority['id']) is int and authority['id'] == 6726673440, 'Authority ID differs')
        require(authority['user']['login'] == 'DouglasNLima' and authority['user']['id'] == 33501911, 'Authority owner differs')
        require(authority['html_url'] == 'https://github.com/DouglasNLima/local-docs-studio/issues/77#issuecomment-6726673440'
                and authority['issue_url'] == 'https://api.github.com/repos/DouglasNLima/local-docs-studio/issues/77', 'Wrong authority issue')
        require(authority['created_at'] == authority['updated_at'] == '2026-11-08T20:25:43Z', 'Authority edited or chronology differs')
        require(sha(authority['body'].encode()) == AUTHORITY_SHA and decode(authority['body']) == expected_authority, 'Authority payload differs')
        require(decode(authority['body'])['approved'] is True, 'Authority not approved')
    require(file_sha(OUTER / 'authority-body.txt') == AUTHORITY_SHA, 'Raw authority body differs')
    outer = read(OUTER / 'driver-exit.json')
    launch = read(OUTER / 'driver-launch.json')
    require(all(outer[key] == value for key, value in launch.items()), 'Launch/exit capture differs')
    require(outer['driverPid'] == 28708 and outer['driverInvocations'] == 1 and outer['retries'] == 0
            and outer['driverExitCode'] == 1, 'Outer driver identity/count/exit differs')
    require(outer['command'] == [plan['pythonExecutable'], '-I', '-S',
            'scripts/native/qualification_hosted/local_job_control.py', '--authorisation-comment-id', '6726673440',
            '--authorisation-body-sha256', AUTHORITY_SHA], 'Outer command differs')
    require(outer['wrapperSha256'] == outer_files['capture_driver.py']
            and outer['stdoutSha256'] == outer_files['driver.stdout.bin']
            and outer['stderrSha256'] == outer_files['driver.stderr.bin'], 'Outer capture hashes differ')
    require(datetime.datetime.fromisoformat(outer['startedUtc']) > datetime.datetime.fromisoformat('2026-11-08T20:25:43+00:00'), 'Launch predates authority')

    record = read(RUN / 'process.json')
    operations = [decode(line) for line in (RUN / 'supervisor.jsonl').read_bytes().splitlines()]
    require(operations == record['operations'] and file_sha(RUN / 'supervisor.jsonl') == record['supervisorJournalSha256'], 'Journal differs from process record')
    require(record['journalComplete'] is True and record['loggingErrors'] == [], 'Journal not complete')
    require(len(operations) == 52 and [event['sequence'] for event in operations] == list(range(52)), 'Missing/reordered operation sequence')
    require(all(number(event['seconds']) for event in operations)
            and [event['seconds'] for event in operations] == sorted(event['seconds'] for event in operations), 'Invalid operation times')
    pairs = []
    for index in range(0, len(operations), 2):
        begin, end = operations[index:index+2]
        require(begin['phase'] == 'BEGIN' and end['phase'] == 'END' and begin['name'] == end['name']
                and end['beginSequence'] == begin['sequence'], 'Broken operation pairing')
        pairs.append((begin, end))
    pair_map = {begin['name']: (begin, end) for begin, end in pairs}
    require(len(pair_map) == 26, 'Repeated operation name')
    expected_names = ['job', 'observe:CREATED_EMPTY', 'configure', 'observe:CONFIGURED_EMPTY', 'parent', 'create',
        'identity-before', 'association-before', 'observe:BEFORE_ASSIGNMENT', 'assign', 'observe:AFTER_ASSIGNMENT',
        'association-after', 'resume', 'observe:AFTER_RESUME', 'wait', 'exit', 'identity-at-exit', 'observe:PROCESS_EXIT',
        'terminate', 'close:thread', 'close:process', *['observe:CLEANUP_' + str(n) for n in range(4)], 'close:job']
    require([begin['name'] for begin, end in pairs] == expected_names, 'Unexpected failure-path sequence')
    failures = [end for begin, end in pairs if 'error' in end]
    require(len(failures) == 1 and failures[0]['name'] == 'identity-at-exit'
            and failures[0]['error']['native'] == {'returnValue': 0, 'winError': 31}, 'Unexpected failed native operation')
    require(pair_map['job'][1]['result'] == record['jobHandle'] == 700, 'Wrong Job handle')
    require(pair_map['create'][1]['result'] == [824, 812, 39616, 12880], 'Wrong created child/thread identity')
    require(record['supervisorPid'] == outer['driverPid'] and record['processId'] == 39616 and record['threadId'] == 12880, 'Process identities differ')
    require(pair_map['create'][0]['arguments'] == {'binary': str(fixture), 'flags': 0x08000004}, 'Wrong creation path/flags')
    require(pair_map['association-before'][1]['result'] is False and pair_map['association-after'][1]['result'] is True, 'Private association observations differ')
    require(pair_map['assign'][0]['arguments'] == {'jobHandle': 700, 'processHandle': 824, 'processId': 39616}
            and pair_map['assign'][1]['result'] == record['assignmentResult'] == {'returnValue': 1, 'winError': None}, 'Assignment evidence differs')
    require(pair_map['configure'][0]['arguments'] == {'jobHandle': 700, 'flags': 0x2008, 'activeLimit': 1}, 'Wrong applied limits')
    require(pair_map['resume'][0]['arguments'] == {'threadHandle': 812}
            and pair_map['resume'][1]['result'] == {'returnValue': 1, 'winError': None}, 'Wrong resume result')
    require(pair_map['wait'][0]['arguments'] == {'processHandle': 824}
            and pair_map['wait'][1]['result']['waitResult'] == 0
            and pair_map['exit'][0]['arguments'] == {'processHandle': 824}
            and pair_map['exit'][1]['result'] == record['exitCode'] == 0, 'Direct child exit evidence differs')
    parent, before = record['parentIdentity'], record['childIdentityBefore']
    require(pair_map['parent'][1]['result'] == parent and parent['processId'] == 28708
            and parent['imageSha256'] == plan['pythonFiles'][plan['pythonExecutable']]
            and parent['inAnyJob'] is True and parent['inPrivateJob'] is False, 'Parent identity differs')
    require(pair_map['identity-before'][1]['result'] == before and before['processId'] == before['threadProcessId'] == 39616
            and before['threadId'] == 12880 and before['imagePath'] == str(fixture)
            and before['imageSha256'] == plan['fixture']['sha256']
            and before['processHandleFlags'] == before['threadHandleFlags'] == 0, 'Pre-resume child identity differs')
    require(record['childIdentityAtExit'] is None, 'Unexpected exit identity')

    entries = record['jobObservations']
    require([entry['phase'] for entry in entries] == PHASES, 'Missing/repeated fixed observation')
    rows = []
    for entry in entries:
        phase, raw = entry['phase'], entry['raw']
        require(set(raw) == {'accounting', 'limits', 'pids'}, 'Incomplete query set')
        for name, information_class, capacity in [('accounting', 1, 48), ('limits', 9, 144), ('pids', 3, 72)]:
            query = raw[name]
            require(type(query['returnValue']) is int and query['returnValue'] != 0 and query['winError'] is None, 'Native query failed')
            require(query['informationClass'] == information_class and query['capacityBytes'] == capacity
                    and len(bytes.fromhex(query['rawBytes'])) == capacity, 'Wrong query ABI or raw capacity')
            require(type(query['returnedBytes']) is int and 0 <= query['returnedBytes'] <= capacity, 'Wrong returned length')
            require(number(query['startedSeconds']) and number(query['finishedSeconds'])
                    and query['startedSeconds'] <= query['finishedSeconds'], 'Wrong query chronology')
        accounting, limits, pids = [bytes.fromhex(raw[key]['rawBytes']) for key in ('accounting', 'limits', 'pids')]
        require(raw['accounting']['returnedBytes'] == 48 and raw['limits']['returnedBytes'] == 144, 'Truncated fixed structure')
        assigned, returned = struct.unpack_from('<II', pids)
        require(assigned == returned <= 8 and 8 + returned * 8 <= raw['pids']['returnedBytes'], 'Truncated/contradictory PID prefix')
        members = list(struct.unpack_from('<' + 'Q' * returned, pids, 8))
        faults, total, active, terminated = struct.unpack_from('<IIII', accounting, 32)
        flags = struct.unpack_from('<I', limits, 16)[0]
        limit = struct.unpack_from('<I', limits, 40)[0]
        decoded = dict(totalProcesses=total, activeProcesses=active, terminatedProcesses=terminated,
            pageFaults=faults, returnedBytes=48, accountingBytes=accounting.hex(), limitFlags=flags,
            activeLimit=limit, assignedProcesses=assigned, processIds=members)
        require(decoded == entry['decoded'], 'Recorded decoding differs from independent struct decode')
        begin, end = pair_map['observe:' + phase]
        require(begin['arguments'] == {'jobHandle': 700} and end['result'] == raw, 'Raw observation/journal mismatch')
        times = [entry['startedSeconds'], begin['seconds'], raw['accounting']['startedSeconds'], raw['accounting']['finishedSeconds'],
                 raw['limits']['startedSeconds'], raw['limits']['finishedSeconds'], raw['pids']['startedSeconds'], raw['pids']['finishedSeconds'],
                 end['seconds'], entry['finishedSeconds']]
        require(all(number(value) for value in times) and times == sorted(times), 'Observation chronology differs')
        require(flags == (0 if phase == 'CREATED_EMPTY' else 0x2008) and limit == (0 if phase == 'CREATED_EMPTY' else 1), 'Limits changed')
        row = dict(phase=phase, startedSeconds=entry['startedSeconds'], finishedSeconds=entry['finishedSeconds'],
                   total=total, active=active, quotaTerminated=terminated, assigned=assigned, pids=members,
                   limitFlags=flags, activeLimit=limit,
                   returnedBytes={name: raw[name]['returnedBytes'] for name in raw})
        if phase.startswith('CLEANUP_'):
            index = int(phase[-1]); target = [0, .1, 1, 4][index]; upper = [.1, 1, 4, 5][index]
            row.update(targetSeconds=target, actualOffsetSeconds=entry['startedSeconds'] - record['cleanupStartedSeconds'],
                withinStartWindow=record['cleanupStartedSeconds'] + target <= entry['startedSeconds'] < record['cleanupStartedSeconds'] + upper,
                finishedWithinCleanupBound=entry['finishedSeconds'] <= record['cleanupStartedSeconds'] + 5)
        rows.append(row)
    require(all(a['finishedSeconds'] <= b['startedSeconds'] for a, b in zip(rows, rows[1:])), 'Overlapping/reordered boundaries')
    require(rows[0]['total'] == rows[1]['total'] == rows[2]['total'] == 0
            and bytes.fromhex(entries[0]['raw']['accounting']['rawBytes']) == bytes(48), 'Initial Job not empty')
    require(all(rows[i]['total'] == rows[i]['active'] == 1 and rows[i]['pids'] == [39616] for i in (3, 4)), 'Suspended/resumed assignment differs')
    require(rows[5]['total'] == 2 and rows[5]['active'] == 1 and rows[5]['pids'] == [57332], 'Unexpected exit snapshot')
    require(all(row['total'] == 2 and row['active'] == 0 and row['pids'] == [] for row in rows[6:]), 'Final membership differs')
    require(all(row['quotaTerminated'] == 0 for row in rows), 'Unexpected quota termination')
    require(record['assignmentObservation'] == entries[3]['decoded'] and record['cleanupObservation'] == entries[-1]['decoded'], 'Summary aliases differ')
    for name, handle in [('close:thread', 812), ('close:process', 824), ('close:job', 700)]:
        require(pair_map[name][0]['arguments'] == {'handle': handle}
                and pair_map[name][1]['result'] == {'returnValue': 1, 'winError': None}, 'Failed/contradictory close')
    require(len(record['terminationRequests']) == 1 and record['terminationRequests'][0]['assigned'] is True
            and pair_map['terminate'][1]['result'] == {'returnValue': 1, 'winError': None}, 'Termination evidence differs')
    require(record['cleanupVerified'] is False and record['emptyMembershipObserved'] is True
            and record['jobHandleClosed'] is True and record['timedOut'] is False, 'Wrong final flags')
    require(record['createdSeconds'] <= record['assignedSeconds'] <= record['resumedSeconds'] <= record['observedExitSeconds'] <= 30,
            'Direct child deadline/order differs')
    require(record['finishedSeconds'] <= record['cleanupStartedSeconds'] + 5 <= 35, 'Cleanup exceeded bound')
    require(record['childHandlesClosedSeconds'] >= entries[5]['finishedSeconds']
            and record['childHandlesClosedSeconds'] <= entries[6]['startedSeconds']
            and record['jobHandleClosedSeconds'] >= entries[-1]['finishedSeconds'], 'Closure chronology differs')
    native = read(RUN / 'stdout.json')
    require(native == plan['expectedFixtureReport'] and (RUN / 'stderr.jsonl').read_bytes() == b'', 'Fixture output differs')
    environment = read(RUN / 'child-environment.json')
    require(sorted(environment) == record['childEnvironmentKeys'] == ['PATH', 'SystemRoot', 'TEMP', 'TMP', 'USERPROFILE', 'WINDIR']
            and sha(json.dumps(environment, sort_keys=True).encode()) == record['childEnvironmentSha256'], 'Child environment differs')
    require(environment['PATH'] == str(Path(environment['SystemRoot']) / 'System32'), 'Child PATH differs')
    require(not (RUN / 'owner-after.json').exists() and not (RUN / 'terminal.json').exists(), 'Unexpected final records')
    sys.path.insert(0, str(ROOT / 'scripts/native/qualification_hosted'))
    from job_evidence import verify_supervision
    rejection = None
    try:
        verify_supervision(record)
    except ValueError as error:
        rejection = str(error)
    require(rejection == 'Supervisor has missing or failed operations', 'Existing verifier did not reject as recorded')
    old_path = 'docs/native/evidence/highcontrast-live-readiness/preparation-evidence.zip'
    old = (ROOT / old_path).read_bytes()
    require(sha(old) == '09e7c8918b1e48fc8cd24f43b700e57dfcff423f31ce4f2cdc5cf562e65fb9aa'
            and old == git('show', E + ':' + old_path), 'Original failure changed')
    with zipfile.ZipFile(ROOT / old_path) as z:
        original = decode(z.read('local-supervisor-control/process.json'))
        require((original['processId'], original['totalProcesses'], original['activeProcesses'], original['cleanupVerified']) ==
                (37804, 2, 1, False), 'Historical failure reclassified')
    audit = dict(schemaVersion=1, kind='INDEPENDENT_READ_ONLY_LOCAL_JOB_RESULT_AUDIT',
        executionCommit=E, executionTree=TREE, sourceCommit=S, planSha256=PLAN_SHA,
        authorityComment=6726673440, authorityBodySha256=AUTHORITY_SHA,
        overall='FAIL_BLOCKED_AUTHORITY_SPENT', sourceAndFileIntegrity='PASS',
        beforeLaunchAuthority='PASS_RETAINED_UNEDITED_OWNER_RECORDS', finalAuthority='NOT_COLLECTED',
        supplementaryPostObservationAuthority='MATCHES_RETAINED_OWNER_RECORD_NOT_A_DRIVER_BOUNDARY',
        canonicalSourceFiles=16, rawSourceFiles=16, pythonFiles=2,
        documentationChangesAtReview=review_worktree_status,
        runFiles=run_files, outerFiles=outer_files, rawQueriesIndependentlyDecoded=30,
        operationRecords=52, operationPairs=26, queryValidity='PASS', observationChronology='PASS_ORDER_ONLY',
        explicitCreateCalls=1, explicitAssignmentCalls=1, jobCreationCalls=1,
        fixturePid=39616, supervisorPid=28708, unidentifiedJobMemberPid=57332,
        singleJobProcessBoundary='FAIL_TOTAL_2_AND_NON_FIXTURE_PID', fixtureExitCode=0,
        fixtureChecks='PASS_21_EXPECTED_REPORT', actualHighContrastCallsReported=0,
        completeExitIdentity='FAIL_QUERY_FULL_PROCESS_IMAGE_NAME_ERROR_31',
        secondaryDiagnosticError='NoneType dereference after failed exit identity',
        fixedCleanupSchedule='FAIL_CLEANUP_1_BEFORE_LOWER_BOUND', observations=rows,
        directChildExitObservedSeconds=record['observedExitSeconds'],
        cleanupElapsedSeconds=record['finishedSeconds'] - record['cleanupStartedSeconds'],
        observationAndCleanupUpperBounds='PASS', emptyMembership='PASS_FOUR_OBSERVED_CLEANUP_SNAPSHOTS',
        termination='ONE_RECORDED_TERMINATE_JOB_SUCCESS', ownedHandleCloses='PASS_THREE_RECORDED_SUCCESSES',
        overallCleanupVerified=False, journalComplete=True, unchangedVerifierRejection=rejection,
        missingEvidence=['owner-after.json', 'terminal.json', 'complete childIdentityAtExit',
                         'image/creation time/parentage of PID 57332', 'exact cause of native error 31',
                         'cause of early CLEANUP_1 timestamp'],
        historicalFailure='PID_37804_ORIGINAL_FAIL_UNCHANGED_CAUSE_INCONCLUSIVE',
        reviewExecution=dict(nativeControls=0, collectors=0, hostedJobs=0, realWin32DiagnosticCalls=0),
        limitations=['Snapshots do not identify PID 57332 or prove which component created/associated it.',
                     'Observed empty membership and successful closes do not erase the extra member or identity/schedule failures.',
                     'The original 2/1 failure is not causally explained by this new observation.',
                     'Captured authority is verified locally; missing post-run authority is not reconstructed.',
                     'No retrospective timing tolerance or process-count normalisation is applied.'])
    (REVIEW / 'audit.json').write_text(json.dumps(audit, indent=2, allow_nan=False) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps({key: audit[key] for key in ('overall', 'sourceAndFileIntegrity', 'rawQueriesIndependentlyDecoded',
        'fixturePid', 'unidentifiedJobMemberPid', 'fixtureChecks', 'singleJobProcessBoundary',
        'completeExitIdentity', 'fixedCleanupSchedule', 'emptyMembership', 'ownedHandleCloses')}, indent=2))


if __name__ == '__main__':
    run()
