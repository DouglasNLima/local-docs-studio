"""Run named offline unittest modules under isolated Python; no native backend."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

root = Path(r'C:\Code\MarkdownReader-native-ux-contract')
phase, *modules = sys.argv[1:]
assert phase and modules and all(m.startswith('test_native_') for m in modules)
output = Path(__file__).resolve().parent / phase
output.mkdir(exist_ok=False)
code = """import ctypes,sys,unittest
from unittest.mock import patch
sys.path.insert(0, 'C:/Code/MarkdownReader-native-ux-contract/tests/unit')
suite=unittest.defaultTestLoader.loadTestsFromNames(sys.argv[1:])
with patch.object(ctypes,'WinDLL',create=True,side_effect=AssertionError('Native diagnostic loading forbidden')):
 result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(not result.wasSuccessful())
"""
command = [sys.executable, '-I', '-S', '-c', code, *modules]
start = time.monotonic()
with (output/'stdout.bin').open('xb') as stdout, (output/'stderr.bin').open('xb') as stderr:
    result = subprocess.run(command, cwd=root, stdout=stdout, stderr=stderr)
sources = ['scripts/native/qualification_hosted/live_process.py',
           'scripts/native/qualification_hosted/job_evidence.py',
           'tests/unit/test_native_supervisor_recovery.py',
           'tests/unit/test_native_job_supervisor.py',
           'tests/unit/job_supervisor_support.py',
           'tests/unit/test_native_live_verification.py']
receipt = dict(kind='OFFLINE_UNITTEST_ONLY', command=command, exitCode=result.returncode,
    seconds=time.monotonic()-start, python=sys.executable, version=sys.version,
    sourceFiles={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sources},
    outputs={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in output.iterdir()},
    nativeFixtures=0, collectors=0, hostedRuns=0)
(output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(phase=phase,exitCode=result.returncode,seconds=receipt['seconds'])))
print((output/'stderr.bin').read_text(encoding='utf-8')[-7000:])
raise SystemExit(result.returncode)
