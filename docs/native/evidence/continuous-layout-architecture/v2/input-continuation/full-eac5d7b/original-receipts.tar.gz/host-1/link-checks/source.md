# Link route

[Open child](child/destination.md)

[External destination](https://example.com/#lens-layout-experiment-cfd01676503440e9bc538e00099c7d60)

Parent destination marker.
