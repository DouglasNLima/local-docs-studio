Before ![Pixel](pixel.png) after.
