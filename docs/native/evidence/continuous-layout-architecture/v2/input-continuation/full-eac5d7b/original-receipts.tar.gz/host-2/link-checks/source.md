# Link route

[Open child](child/destination.md)

[External destination](https://example.com/#lens-layout-experiment-5c9f1e3c33664841ace4daff462a1fd7)

Parent destination marker.
