<details>
<summary>Hidden section</summary>

## Deep target

Hidden Café 😀 é content.

</details>

After fold.