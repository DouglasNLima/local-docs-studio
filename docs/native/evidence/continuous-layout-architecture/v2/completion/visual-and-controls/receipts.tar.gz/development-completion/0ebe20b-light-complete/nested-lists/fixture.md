3. **First** item

   continuation *italic*

   - nested unordered
     7. nested ordered
     8. another nested

4. Second item

   another paragraph

After list.