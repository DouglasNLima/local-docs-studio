using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using System.Text.Json;
class Program {
 [STAThread] static void Main(string[] args) {
 var app=new Application(); var window=new Window {Width=340,Height=240,Title="CONTROL ONLY - selection compositing"}; var results=new List<object>(); bool started=false; window.Content=new Border();
 window.ContentRendered += async (_,_) => { if(started)return; started=true; try {
 foreach(var palette in new[]{("Light","#FFFFFF","#FF883E"),("Dark","#202124","#FF883E"),("HC colours only; OS unchanged","#202020","#8EE3F0")}) {
 var bg=(Color)ColorConverter.ConvertFromString(palette.Item2); var fg=(Color)ColorConverter.ConvertFromString(palette.Item3);
 var table=new Table {CellSpacing=0}; table.Columns.Add(new TableColumn {Width=new GridLength(130)}); table.Columns.Add(new TableColumn {Width=new GridLength(130)});
 var group=new TableRowGroup();table.RowGroups.Add(group);TableCell? first=null,last=null;
 for(int r=0;r<2;r++) { var row=new TableRow();group.Rows.Add(row);for(int c=0;c<2;c++) {var cell=new TableCell(new Paragraph(new Run("Cell"))){Padding=new Thickness(8,6,8,6)};row.Cells.Add(cell);if(c==1){first??=cell;last=cell;}} }
 var doc=new FlowDocument(table){PagePadding=new Thickness(12),FontFamily=new FontFamily("Segoe UI"),FontSize=15,Background=new SolidColorBrush(bg)};
 var viewer=new FlowDocumentScrollViewer {Document=doc,Width=320,Height=200,Background=new SolidColorBrush(bg),SelectionOpacity=.3,SelectionBrush=new SolidColorBrush(fg),IsToolBarVisible=false};
 window.Content=viewer;window.UpdateLayout();await Dispatcher.Yield(DispatcherPriority.ApplicationIdle);
 viewer.Selection.Select(first!.ContentStart,last!.ContentEnd);window.Activate();viewer.Focus();window.UpdateLayout();await Dispatcher.Yield(DispatcherPriority.ApplicationIdle);
 var rect=first.ContentStart.GetCharacterRect(LogicalDirection.Forward);var shot=new RenderTargetBitmap(320,200,96,96,PixelFormats.Pbgra32);shot.Render(viewer);var stock=new byte[4];shot.CopyPixels(new Int32Rect((int)rect.X+1,(int)rect.Y+1,1,1),stock,4,0);
 var variants=new List<object>();foreach(var kind in new[]{"BrushOpacity","QuantisedOpacity","ColourAlpha","LayerOpacity"}) {
 var parent=new DrawingVisual();using(var dc=parent.RenderOpen())dc.DrawRectangle(new SolidColorBrush(bg),null,new Rect(0,0,4,4));
 var child=new DrawingVisual();parent.Children.Add(child);var colour=fg;var opacity=1d;if(kind=="ColourAlpha")colour.A=(byte)(255*.3);else if(kind=="LayerOpacity")child.Opacity=.3;else opacity=kind=="QuantisedOpacity"?(byte)(255*.3)/255d:.3;
 using(var dc=child.RenderOpen())dc.DrawRectangle(new SolidColorBrush(colour){Opacity=opacity},null,new Rect(0,0,4,4));
 var bitmap=new RenderTargetBitmap(4,4,96,96,PixelFormats.Pbgra32);bitmap.Render(parent);var pixel=new byte[4];bitmap.CopyPixels(new Int32Rect(1,1,1,1),pixel,4,0);variants.Add(new{Kind=kind,Pixel=pixel,Exact=stock.SequenceEqual(pixel)});
 }
 results.Add(new{Palette=palette.Item1,Stock=stock,Variants=variants}); }
 File.WriteAllText(args[0],JsonSerializer.Serialize(new{ActualOsHighContrast=SystemParameters.HighContrast,Results=results},new JsonSerializerOptions{WriteIndented=true}));
 } finally {window.Close();app.Shutdown();} };window.Show();app.Run(); }
}
