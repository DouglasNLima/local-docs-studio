+-----------------------+-----------------------+
| First paragraph.      | **Rich cell**         |
|                       |                       |
| Second *paragraph*.   | - Nested first        |
|                       | - Nested second       |
+-----------------------+-----------------------+

After nested table.