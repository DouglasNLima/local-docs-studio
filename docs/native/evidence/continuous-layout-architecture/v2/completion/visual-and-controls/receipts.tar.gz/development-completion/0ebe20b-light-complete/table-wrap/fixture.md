| Left | Centre | Right |
|:---|:---:|---:|
| **first** cell | centre content | final value |
| long wrapped cell long wrapped cell long wrapped cell long wrapped cell long wrapped cell long wrapped cell long wrapped cell long wrapped cell long wrapped cell long wrapped cell long wrapped cell long wrapped cell long wrapped cell long wrapped cell long wrapped cell long wrapped cell | é 😀 | 12345 |

After table.