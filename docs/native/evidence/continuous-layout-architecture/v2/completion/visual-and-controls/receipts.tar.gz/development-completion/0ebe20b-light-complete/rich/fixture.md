## Heading

Plain **bold** *italic* and `code` &amp; escaped \* star. é 😀

Hard break line.  
Next line after hard break.

++under++ ~~strike~~ ==mark== H~2~O x^2^.

```csharp
// comment
var count = 42;
```

[Deep link](#final-heading)

## Final heading

Final marker.