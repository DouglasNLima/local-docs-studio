5. Outer first

   - Child unordered

     7. Nested ordered
     8. Next ordered

6. Outer next

After numbered nesting.